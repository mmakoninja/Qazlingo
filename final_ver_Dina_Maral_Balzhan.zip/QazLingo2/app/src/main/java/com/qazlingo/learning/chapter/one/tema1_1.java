package com.qazlingo.learning.chapter.one;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.qazlingo.learning.R;

public class tema1_1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zat_esym);
    }
}