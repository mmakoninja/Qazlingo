package com.qazlingo.learning;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class LeaderboardFragment extends Fragment {
    private TextView frontText, backText;
    private Button nextButton;

    private String[] vocabularyList; // Список слов
    private int currentIndex; // Текущий индекс карточки

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_leaderboard, container, false);

        frontText = view.findViewById(R.id.front_text);
        backText = view.findViewById(R.id.back_text);
        nextButton = view.findViewById(R.id.next_button);

        vocabularyList = new String[]{"Word 1", "Word 2", "Word 3", "Word 4"}; // Замените на ваш список слов
        currentIndex = 0;

        displayCurrentCard();

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentIndex++;
                if (currentIndex < vocabularyList.length) {
                    displayCurrentCard();
                } else {
                    // Показываем сообщение или выполняем другую логику при достижении конца списка
                    // Например, можно сбросить индекс и показать первую карточку
                    currentIndex = 0;
                    displayCurrentCard();
                }
            }
        });

        return view;
    }

    private void displayCurrentCard() {
        // Устанавливаем тексты на карточке
        frontText.setText(vocabularyList[currentIndex]);
        backText.setText(getBackTextForIndex(currentIndex)); // Замените на логику получения текста с обратной стороны карточки
    }

    private String getBackTextForIndex(int index) {
        // Возвращает текст для обратной стороны карточки по индексу
        // Можете реализовать свою логику здесь
        // Например, можно хранить пары слов (слово на лицевой стороне и его перевод на обратной стороне) и получать перевод по индексу
        // Возвращаем просто обратное слово для примера
        return new StringBuilder(vocabularyList[index]).reverse().toString();
    }
}