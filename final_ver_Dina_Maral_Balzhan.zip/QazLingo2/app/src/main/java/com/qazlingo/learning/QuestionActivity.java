package com.qazlingo.learning;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.TextView;
import android.app.Dialog;


import com.qazlingo.learning.databinding.ActivityQuestionBinding;
import com.qazlingo.learning.databinding.ActivitySetsBinding;

import java.util.ArrayList;

public class QuestionActivity extends AppCompatActivity {

    ArrayList<QuestionModel> list = new ArrayList<>();
    private int count = 0;
    private int position = 0;
    private int score = 0;
    CountDownTimer timer;

    ActivityQuestionBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityQuestionBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //TextView questionTextView = findViewById(R.id.question);
        //questionTextView.setText("Test question");

        resetTimer();
        timer.start();



        String setName = getIntent().getStringExtra("set");

        if (setName.equals("SET-1")) {
            setOne();
        } else if (setName.equals("SET-2")) {
            setTwo();
        }
        showQuestion();

        binding.option1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswer((Button) view);
            }
        });

        binding.option2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswer((Button) view);
            }
        });

        binding.option3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswer((Button) view);
            }
        });

        binding.option4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswer((Button) view);
            }
        });


        playAnimation(binding.question, 0, list.get(position).getQuestion());

        binding.btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(timer!=null){
                    timer.cancel();
                }

                timer.start();

                binding.btnNext.setEnabled(false);
                binding.btnNext.setAlpha((float) 0.3);
                enableOption(true);
                position++;

                if (position == list.size()) {
                    Intent intent = new Intent(QuestionActivity.this, ScoreActivity.class);
                    intent.putExtra("score", score);
                    intent.putExtra("total", list.size());
                    startActivity(intent);
                    finish();
                    return;
                }

                count = 0;
                showQuestion();

                playAnimation(binding.question, 0, list.get(position).getQuestion());


                //playAnimation(binding.question, 0, list.get(position).getQuestion());
            }
        });
    }

    private void resetTimer() {
        timer = new CountDownTimer(30000, 1000) {
            @Override
            public void onTick(long l) {
                binding.timer.setText(String.valueOf(l / 1000));
            }

            @Override
            public void onFinish() {
                if (!isFinishing()) {
                    Dialog dialog = new Dialog(QuestionActivity.this);
                    dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
                    dialog.setCancelable(false);
                    dialog.setContentView(R.layout.timeout_dialog);
                    dialog.findViewById(R.id.tryAgain).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(QuestionActivity.this, SetsActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    });

                    dialog.show();
                }
            }
        };

        timer.start();
    }


    private void showQuestion() {
        QuestionModel question = list.get(position);
        binding.question.setText(question.getQuestion());
        binding.totalQuestion.setText((position + 1) + "/" + list.size());

        ArrayList<String> options = new ArrayList<>();
        options.add(question.getOptionA());
        options.add(question.getOptionB());
        options.add(question.getOptionC());
        options.add(question.getOptionD());

        binding.option1.setText(options.get(0));
        binding.option2.setText(options.get(1));
        binding.option3.setText(options.get(2));
        binding.option4.setText(options.get(3));

    }



    private void playAnimation(View view, int value, String data) {
        view.animate().alpha(value).scaleX(value).scaleY(value).setDuration(500).setStartDelay(100)
                .setInterpolator(new DecelerateInterpolator()).setListener(new Animator.AnimatorListener() {
                    @Override
                    public void onAnimationStart(@NonNull Animator animation) {


                        if (value == 0 && count < 4) {
                            String option = "";

                            if (count == 0) {
                                option = list.get(position).getOptionA();
                            } else if (count == 1) {
                                option = list.get(position).getOptionB();
                            } else if (count == 2) {
                                option = list.get(position).getOptionC();
                            } else if (count == 3) {
                                option = list.get(position).getOptionD();
                            }

                            playAnimation(binding.optionContainer.getChildAt(count), 0, option);
                            count++;
                        }
                    }

                    @Override
                    public void onAnimationEnd(@NonNull Animator animation) {
                        if (value == 0) {
                            try {
                                ((TextView) view).setText(data);
                                binding.totalQuestion.setText(position + 1 + "/" + list.size());
                            } catch (Exception e) {
                                ((Button) view).setText(data);
                            }
                            view.setTag(data);
                            playAnimation(view, 1, data);
                        }
                    }

                    @Override
                    public void onAnimationCancel(@NonNull Animator animation) {}

                    @Override
                    public void onAnimationRepeat(@NonNull Animator animation) {}
                });
    }

    private void enableOption(boolean enable) {
        for (int i = 0; i < 4; i++) {
            View childView = binding.optionContainer.getChildAt(i);
            if (childView instanceof Button) {
                Button optionButton = (Button) childView;
                optionButton.setEnabled(enable);
                if (enable) {
                    optionButton.setBackgroundResource(R.drawable.btn_opt);
                }
            }
        }
    }

    private void checkAnswer(Button selectedOption) {
    if(timer!=null){
    timer.cancel();
        }

        if (selectedOption != null) {
            binding.btnNext.setEnabled(true);
            binding.btnNext.setAlpha(1);

            if (selectedOption.getText().toString().equals(list.get(position).getCorrectAnswer())) {
                score++;
                selectedOption.setBackgroundResource(R.drawable.right_answ);
            } else {
                selectedOption.setBackgroundResource(R.drawable.wrong_answ);
                Button correctOption = (Button) binding.optionContainer.findViewWithTag(list.get(position).getCorrectAnswer());
                if (correctOption != null) {
                    correctOption.setBackgroundResource(R.drawable.right_answ);
                }
            }
        } else {


            // Обработка случая, когда selectedOption равен null
            // Вы можете вывести сообщение об ошибке или выполнить другие действия по вашему усмотрению

            Intent intent = new Intent(QuestionActivity.this, SplashActivity.class);
            startActivity(intent);
            finish();
        }
    }

    private void setOne() {

        list.add(new QuestionModel("Find the correct ending for the word ayaldama","da","de","ta","te","da"));
        list.add(new QuestionModel("Choose the correct ending: men oz oiymdy ait.. dep edim", "iyn", "aiyn", "in", "ein","aiyn"));
        list.add(new QuestionModel("Find the word with the soft (front) consonants.", "adam", "ini", "bala", "qala","ini"));
        list.add(new QuestionModel("Complete the row of pronouns: menin, ..., sizdin, olardyn", "senin", "bizdin", "sen", "siz","bizdin"));
        list.add(new QuestionModel(" Find the right translation of “My parents are at work”", "Onyn ata anasy zhumysta", "Bizdin ata anamyz zhumysta", "Menin ata anam zhumysta", "Olardyn ata anasy zhumysta","Menin ata anam zhumysta"));
    }

    private void setTwo() {
        list.add(new QuestionModel("Find the correct ending for the word ayaldama","da","de","ta","te","da"));
        list.add(new QuestionModel("Choose the correct ending: men oz oiymdy ait.. dep edim", "iyn", "aiyn", "in", "ein","aiyn"));
        list.add(new QuestionModel("Find the word with the soft (front) consonants.", "adam", "ini", "bala", "qala","ini"));
        list.add(new QuestionModel("Complete the row of pronouns: menin, ..., sizdin, olardyn", "senin", "bizdin", "sen", "siz","bizdin"));
    }
}
