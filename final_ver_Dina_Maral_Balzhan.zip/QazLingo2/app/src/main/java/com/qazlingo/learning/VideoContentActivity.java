package com.qazlingo.learning;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class VideoContentActivity extends AppCompatActivity {
    private ViewPager2 viewPager2;
    private List<VideoModel> videoList;
    private VideoAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_content);

        videoList=new ArrayList<>();
        viewPager2=findViewById(R.id.viewPager2);
        videoList.add(new VideoModel("android.resource://"+getPackageName()+"/"+R.raw.d,"Lesson-1","Example to verb: Listen, Write, Smile"));
        videoList.add(new VideoModel("android.resource://"+getPackageName()+"/"+R.raw.e,"Lesson-2","Example to verb: Listen, Write, Smile"));
        videoList.add(new VideoModel("android.resource://"+getPackageName()+"/"+R.raw.f,"Lesson-3","Example to verb: Listen, Write, Smile"));
        videoList.add(new VideoModel("android.resource://"+getPackageName()+"/"+R.raw.a,"Lesson-4","In this video we will learn new word"));
        videoList.add(new VideoModel("android.resource://"+getPackageName()+"/"+R.raw.b,"Lesson-5","In this video we will learn new word"));
        videoList.add(new VideoModel("android.resource://"+getPackageName()+"/"+R.raw.c,"Lesson-6","In this video we will learn new word"));


        adapter=new VideoAdapter(videoList);
        viewPager2.setAdapter(adapter);
    }
}