package com.qazlingo.learning;

import android.content.Intent;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.qazlingo.learning.R;
import com.qazlingo.learning.TopicActivity;


public class HomeFragment extends Fragment implements View.OnClickListener{

    CardView topic1,topic2,topic3,topic4;
    ImageView img1,img2,img3,img4;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        topic1 = view.findViewById(R.id.topic1);
        topic2 = view.findViewById(R.id.topic2);
        topic3 = view.findViewById(R.id.topic3);
        topic4 = view.findViewById(R.id.topic4);

        img1 = view.findViewById(R.id.img1);
        img2 = view.findViewById(R.id.img2);
        img3 = view.findViewById(R.id.img3);
        img4 = view.findViewById(R.id.img4);

        loadImage();

        topic1.setOnClickListener(this);
        topic2.setOnClickListener(this);
        topic3.setOnClickListener(this);
        topic4.setOnClickListener(this);



        return view;
    }

    private void loadImage() {
        Glide.with(getContext()).
                load("https://firebasestorage.googleapis.com/v0/b/diploma-qazlingo.appspot.com/o/cover-how-to-create-an-online-course-730x404.png?alt=media&token=2593e14e-75e4-4c77-8b83-ff77bdd8e161").
                into(img1);
        Glide.with(getContext())
                .load("https://firebasestorage.googleapis.com/v0/b/diploma-qazlingo.appspot.com/o/how-to-start-an-online-course-abroad-ru-730x404.png?alt=media&token=99bcffba-8dc6-450d-957d-43fbb89d5089")
                .into(img2);
        Glide.with(getContext()).
                load("https://firebasestorage.googleapis.com/v0/b/diploma-qazlingo.appspot.com/o/cover-how-to-create-an-online-course-730x404.png?alt=media&token=2593e14e-75e4-4c77-8b83-ff77bdd8e161").
                into(img3);
        Glide.with(getContext())
                .load("https://firebasestorage.googleapis.com/v0/b/diploma-qazlingo.appspot.com/o/imgS.png?alt=media&token=fd24328e-e4bf-47eb-829b-fc53b25c668b")
                .into(img4);


    }

    @Override
    public void onClick(View view) {
//there switches
        Intent intent = new Intent(getContext(),VideoContentActivity.class);

        switch (view.getId()){
            case R.id.topic1:
                intent.putExtra("chapterName","topic1");
                startActivity(intent);
                break;
            case R.id.topic2:
                intent.putExtra("chapterName","topic2");
                startActivity(intent);
                break;
            case R.id.topic3:
                intent.putExtra("chapterName","topic3");
                startActivity(intent);
                break;
            case R.id.topic4:
                intent.putExtra("chapterName","topic4");
                startActivity(intent);
                break;
            case R.id.topic5:
                intent.putExtra("chapterName","topic5");
                startActivity(intent);
                break;
        }
    }
}