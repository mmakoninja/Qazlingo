package com.qazlingo.learning.chapter.three;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.qazlingo.learning.R;

public class tema3_1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_etystik);
    }
}