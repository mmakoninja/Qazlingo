package com.qazlingo.learning;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.qazlingo.learning.chapter.four.tema4_1;
import com.qazlingo.learning.chapter.one.tema1_1;
import com.qazlingo.learning.chapter.one.tema1_2;
import com.qazlingo.learning.chapter.three.tema3_1;
import com.qazlingo.learning.chapter.two.tema2_1;

public class TopicActivity extends AppCompatActivity {

    Toolbar toolbar;
    ExpandableHeightGridView gridView;
    String chapterName;
    TopicAdapter adapter;
    String arr[] = null;
    ImageView chapterImage;


    String chapter1[] = {"Alphabet","Numbers","Zhak","TopWords"};
    String chapter2[] = {"SozTaby","sub2","sub2","sub2"};
    String chapter3[] = {"Soylem","sub3","sub3","sub3"};
    String chapter4[] = {"Septyk","sub4","sub4","sub4"};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topic);

        toolbar = findViewById(R.id.toolbar);
        gridView = findViewById(R.id.topics_name);
        gridView.setExpanded(true);

        setSupportActionBar(toolbar);
        if(getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        chapterName = getIntent().getStringExtra("chapterName");
        chapterImage = findViewById(R.id.chapter_image);


        compareAndOpen();


    }

    private void compareAndOpen() {
        if (chapterName.equals("topic1")) {
            arr = chapter1;
            Glide.with(TopicActivity.this).
                    load("https://firebasestorage.googleapis.com/v0/b/diploma-qazlingo.appspot.com/o/edukacija.jpg?alt=media&token=02067c43-79b8-4695-9f7b-aa9a6092b6aa").
                    into(chapterImage);
//            chapterImage.setImageResource(R.drawable.imgf);
            getSupportActionBar().setTitle("topic 1");
        }
        else if (chapterName.equals("topic2")){
            arr = chapter2;
            Glide.with(TopicActivity.this)
                    .load("https://firebasestorage.googleapis.com/v0/b/diploma-qazlingo.appspot.com/o/5fff075714626667961798.jpg?alt=media&token=5f1c1ed2-520e-402a-aa33-cade7c8b90e7")
                    .into(chapterImage);
//            chapterImage.setImageResource(R.drawable.imgs);
            getSupportActionBar().setTitle("topic 2");

        }
        else if (chapterName.equals("topic3")){
            arr = chapter3;
            Glide.with(TopicActivity.this)
                    .load("https://firebasestorage.googleapis.com/v0/b/diploma-qazlingo.appspot.com/o/glubokiy_kontent_kogda_on_nugen_a_kogda_net_14792783302106_image.jpg?alt=media&token=697b90ef-6daa-4832-91d2-511fa1c4843c")
                    .into(chapterImage);

//            chapterImage.setImageResource(R.drawable.imgf);
            getSupportActionBar().setTitle("topic 3");
        }
        else if (chapterName.equals("topic4")){
            arr = chapter4;
            Glide.with(TopicActivity.this)
                    .load("https://firebasestorage.googleapis.com/v0/b/diploma-qazlingo.appspot.com/o/cover-how-to-create-an-online-course-730x404.png?alt=media&token=2593e14e-75e4-4c77-8b83-ff77bdd8e161")
                    .into(chapterImage);

//            chapterImage.setImageResource(R.drawable.imgs);
            getSupportActionBar().setTitle("topic 4");
        }
        else if (chapterName.equals("topic5")){
            arr = chapter4;
            Glide.with(TopicActivity.this)
                    .load("https://firebasestorage.googleapis.com/v0/b/diploma-qazlingo.appspot.com/o/imgS.png?alt=media&token=fd24328e-e4bf-47eb-829b-fc53b25c668b")
                    .into(chapterImage);

//            chapterImage.setImageResource(R.drawable.imgs);
            getSupportActionBar().setTitle("topic 5");
        }
        else{
            arr = null;}

        adapter = new TopicAdapter(arr,TopicActivity.this);
        gridView.setAdapter(adapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                openActivity(arr[i]);
            }
        });
    }

    private void openActivity(String s) {
        switch (s){
            case "Alphabet":
                startActivity(new Intent(TopicActivity.this, tema1_1.class));
                break;
            case "Numbers":
                startActivity(new Intent(TopicActivity.this, tema1_2.class));
                break;
            case "SozTaby":
                startActivity(new Intent(TopicActivity.this, tema2_1.class));
                break;
            case "Soylem":
                startActivity(new Intent(TopicActivity.this, tema3_1.class));
                break;
            case "Septyk":
                startActivity(new Intent(TopicActivity.this, tema4_1.class));
                break;

        }
    }
}